package uz.zapis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

// Ekrandagi hech narsani o'qimaydi. Faqat Android'ga "bu dastur fonda mikrofondan foydalana oladi"
// deb bildirish uchun kerak. Qo'ng'iroq boshlanganda PhoneReceiver yozishni shu orqali boshlaydi.
class CallAccessibility : AccessibilityService() {
    companion object { @Volatile var instance: CallAccessibility? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; Recorder.stop(); super.onDestroy() }
}
