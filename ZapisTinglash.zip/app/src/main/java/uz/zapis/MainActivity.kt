package uz.zapis

import android.Manifest
import android.app.AlertDialog
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.provider.DocumentsContract
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

data class Rec(val uri: Uri, val name: String, val endMs: Long, val size: Long)
data class Call(val number: String, val name: String?, val date: Long, val dur: Long,
                val type: Int, var rec: Rec? = null)

class MainActivity : AppCompatActivity() {
    private var all = listOf<Call>()
    private var recs = listOf<Rec>()
    private val adapter = CallAdapter()
    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) { load() }
    private val treeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            getSharedPreferences("p", MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            load()
        }
    }
    private var diag = ""
    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()) { load() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = this@MainActivity.adapter
        }
        findViewById<CheckBox>(R.id.onlyRec).setOnCheckedChangeListener { _, _ -> refresh() }
        findViewById<Button>(R.id.pick).setOnClickListener { treeLauncher.launch(null) }
        findViewById<Button>(R.id.clean).setOnClickListener { cleanOld() }
        val need = mutableListOf(Manifest.permission.READ_CALL_LOG)
        need += if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load()
        else permLauncher.launch(need.toTypedArray())
    }

    override fun onResume() { super.onResume(); if (all.isNotEmpty()) load() }

    // Faqat ochilganda bir marta o'qiydi. Fonda hech narsa ishlamaydi => batareya sarflanmaydi.
    private fun load() {
        Thread {
            val r = loadRecs(); val c = loadCalls(); match(c, r)
            runOnUiThread { recs = r; all = c; refresh() }
        }.start()
    }

    private fun loadRecs(): List<Rec> {
        val tree = getSharedPreferences("p", MODE_PRIVATE).getString("tree", null)
        if (tree != null) {
            val r = loadFromTree(Uri.parse(tree))
            diag = "Tanlangan papka: ${r.size} ta fayl"
            return r
        }
        val list = mutableListOf<Pair<Rec, String>>()
        val paths = HashMap<String, Int>()
        try {
            val p = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DATE_MODIFIED, MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.RELATIVE_PATH)
            contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, p, null, null,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC")?.use {
                while (it.moveToNext()) {
                    val path = it.getString(4) ?: ""
                    paths[path] = (paths[path] ?: 0) + 1
                    list += Rec(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it.getLong(0)),
                        it.getString(1) ?: "", it.getLong(2) * 1000, it.getLong(3)) to path
                }
            }
        } catch (_: Exception) {}
        diag = if (paths.isEmpty()) "Telefonda audio fayl ko'rinmadi (ruxsatni tekshiring)"
               else "Audio papkalar: " + paths.entries.sortedByDescending { it.value }.take(8)
                    .joinToString { "${it.key.ifBlank { "/" }} (${it.value})" }
        val calls = list.filter { it.second.contains("call", true) }
        val chosen = if (calls.isNotEmpty()) calls else list.filter {
            Regex("call|record|запис|звон|rec", RegexOption.IGNORE_CASE).containsMatchIn(it.second + it.first.name) }
        return chosen.map { it.first }
    }

    private fun loadFromTree(tree: Uri, docId: String = DocumentsContract.getTreeDocumentId(tree), depth: Int = 0): List<Rec> {
        val out = mutableListOf<Rec>()
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val p = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_MIME_TYPE)
            contentResolver.query(children, p, null, null, null)?.use {
                while (it.moveToNext()) {
                    val id = it.getString(0); val mime = it.getString(4) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < 2) out += loadFromTree(tree, id, depth + 1)
                    } else if (mime.startsWith("audio") || mime.startsWith("video") ||
                        (it.getString(1) ?: "").lowercase().matches(Regex(".*\\.(m4a|mp3|amr|3gp|aac|wav|ogg|mp4)"))) {
                        out += Rec(DocumentsContract.buildDocumentUriUsingTree(tree, id),
                            it.getString(1) ?: "", it.getLong(2), it.getLong(3))
                    }
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun loadCalls(): List<Call> {
        val out = mutableListOf<Call>()
        try {
            val p = arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE,
                CallLog.Calls.DURATION, CallLog.Calls.TYPE)
            contentResolver.query(CallLog.Calls.CONTENT_URI, p, null, null, "${CallLog.Calls.DATE} DESC")?.use {
                while (it.moveToNext() && out.size < 500)
                    out += Call(it.getString(0) ?: "", it.getString(1), it.getLong(2), it.getLong(3), it.getInt(4))
            }
        } catch (_: Exception) {}
        return out
    }

    // Yozuvni qo'ng'iroqqa vaqt (va fayl nomidagi raqam) bo'yicha bog'laydi
    private fun match(calls: List<Call>, recs: List<Rec>) {
        val used = HashSet<Uri>()
        for (c in calls) {
            if (c.dur <= 0) continue
            val expectedEnd = c.date + c.dur * 1000
            val tail = c.number.filter { it.isDigit() }.takeLast(7)
            var best: Rec? = null; var bestDiff = Long.MAX_VALUE
            for (r in recs) {
                if (r.uri in used) continue
                val diff = r.endMs - expectedEnd
                if (diff < -30_000 || diff > 120_000) continue
                val nameDigits = r.name.filter { it.isDigit() }
                if (tail.length == 7 && nameDigits.length >= 12 && !nameDigits.contains(tail)) continue
                if (abs(diff) < bestDiff) { bestDiff = abs(diff); best = r }
            }
            if (best != null) { c.rec = best; used += best.uri }
        }
    }

    private fun refresh() {
        val only = findViewById<CheckBox>(R.id.onlyRec).isChecked
        adapter.items = if (only) all.filter { it.rec != null } else all
        adapter.notifyDataSetChanged()
        val mb = recs.sumOf { it.size } / 1024.0 / 1024.0
        findViewById<TextView>(R.id.summary).text =
            "Telefon yozuvlari: ${recs.size} ta, ${"%.1f".format(mb)} MB" +
            if (recs.isEmpty()) "\nYozuvlar topilmadi.\n$diag\nPastdagi tugma bilan yozuvlar saqlanadigan papkani o'zingiz tanlang." else ""
    }

    private fun cleanOld() {
        val limit = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        val old = recs.filter { it.endMs < limit }
        if (old.isEmpty()) { Toast.makeText(this, "30 kundan eski yozuv yo'q", Toast.LENGTH_SHORT).show(); return }
        val mb = old.sumOf { it.size } / 1024.0 / 1024.0
        AlertDialog.Builder(this).setMessage("${old.size} ta yozuv (${"%.1f".format(mb)} MB) o'chirilsinmi?")
            .setPositiveButton("Ha") { _, _ ->
                if (getSharedPreferences("p", MODE_PRIVATE).getString("tree", null) != null) {
                    old.forEach { try { DocumentsContract.deleteDocument(contentResolver, it.uri) } catch (_: Exception) {} }
                    load(); return@setPositiveButton
                }
                val sender = MediaStore.createDeleteRequest(contentResolver, old.map { it.uri }).intentSender
                deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
            }.setNegativeButton("Yo'q", null).show()
    }

    private fun play(c: Call) {
        val rec = c.rec ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_player, null)
        val seek = v.findViewById<SeekBar>(R.id.seek)
        val playBtn = v.findViewById<ImageButton>(R.id.play)
        val time = v.findViewById<TextView>(R.id.time)
        val speedBtn = v.findViewById<Button>(R.id.speed)
        v.findViewById<TextView>(R.id.pTitle).text = "${c.name ?: c.number}\n${fmt.format(Date(c.date))}"
        val mp = MediaPlayer()
        val h = Handler(Looper.getMainLooper())
        try { mp.setDataSource(this, rec.uri); mp.prepare() }
        catch (e: Exception) { Toast.makeText(this, "Ochib bo'lmadi", Toast.LENGTH_SHORT).show(); mp.release(); return }
        seek.max = mp.duration
        val tick = object : Runnable { override fun run() {
            seek.progress = mp.currentPosition
            time.text = "${dur(mp.currentPosition / 1000L)} / ${dur(mp.duration / 1000L)}"
            if (mp.isPlaying) h.postDelayed(this, 500)
        } }
        fun start() { mp.start(); playBtn.setImageResource(android.R.drawable.ic_media_pause); h.post(tick) }
        playBtn.setOnClickListener {
            if (mp.isPlaying) { mp.pause(); playBtn.setImageResource(android.R.drawable.ic_media_play) } else start()
        }
        mp.setOnCompletionListener { playBtn.setImageResource(android.R.drawable.ic_media_play); tick.run() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { mp.seekTo(p); time.text = "${dur(p / 1000L)} / ${dur(mp.duration / 1000L)}" } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val speeds = floatArrayOf(1f, 1.5f, 2f, 0.75f); var si = 0
        speedBtn.setOnClickListener {
            si = (si + 1) % speeds.size
            try { mp.playbackParams = mp.playbackParams.setSpeed(speeds[si]); if (!mp.isPlaying) mp.pause() } catch (_: Exception) {}
            speedBtn.text = "${speeds[si]}x"
        }
        val d = AlertDialog.Builder(this).setView(v).setOnDismissListener { h.removeCallbacksAndMessages(null); mp.release() }.create()
        d.show(); start()
    }

    private fun dur(s: Long) = "%d:%02d".format(s / 60, s % 60)

    inner class CallAdapter : RecyclerView.Adapter<CallAdapter.VH>() {
        var items = listOf<Call>()
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val type: TextView = v.findViewById(R.id.type); val title: TextView = v.findViewById(R.id.title)
            val sub: TextView = v.findViewById(R.id.sub); val mic: ImageButton = v.findViewById(R.id.mic)
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_call, p, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(h: VH, i: Int) {
            val c = items[i]
            h.type.text = when (c.type) {
                CallLog.Calls.OUTGOING_TYPE -> "↗"; CallLog.Calls.INCOMING_TYPE -> "↙"; else -> "✕" }
            h.title.text = if (c.name.isNullOrBlank()) c.number.ifBlank { "Noma'lum" } else c.name
            h.sub.text = (if (c.name.isNullOrBlank()) "" else c.number + " · ") +
                "${fmt.format(Date(c.date))} · ${dur(c.dur)}"
            h.mic.visibility = if (c.rec != null) View.VISIBLE else View.INVISIBLE
            h.mic.setOnClickListener { play(c) }
        }
    }
}
