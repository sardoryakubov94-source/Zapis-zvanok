package uz.zapis

import android.Manifest
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.DialogInterface
import android.content.SharedPreferences
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.provider.DocumentsContract
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.telephony.TelephonyManager
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

data class Rec(val uri: Uri, val name: String, val endMs: Long, val size: Long)
data class Call(val number: String, val name: String?, val date: Long, val dur: Long,
                val type: Int, var rec: Rec? = null)

class MainActivity : AppCompatActivity() {
    private var all = listOf<Call>()
    private var recs = listOf<Rec>()
    private val adapter = CallAdapter()
    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) { load() }
    private val treeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            getSharedPreferences("p", MODE_PRIVATE).edit().putString("tree", uri.toString()).apply()
            load()
        }
    }
    private var diag = ""
    private val dayFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    private var dayFilter: Long? = null
    private val prefs: SharedPreferences get() = getSharedPreferences("p", MODE_PRIVATE)
    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()) { load() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity); adapter = this@MainActivity.adapter
        }
        findViewById<ImageButton>(R.id.recBtn).setOnClickListener { toggleRecord() }
        findViewById<TextView>(R.id.dateFilter).setOnClickListener { dayFilter = null; refresh() }
        val need = mutableListOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        need += if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                else Manifest.permission.READ_EXTERNAL_STORAGE
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load()
        else permLauncher.launch(need.toTypedArray())
    }

    override fun onResume() { super.onResume(); if (all.isNotEmpty()) load() else updateRecBtn() }

    // Faqat ochilganda bir marta o'qiydi. Fonda hech narsa ishlamaydi => batareya sarflanmaydi.
    private fun load() {
        Thread {
            val r = loadRecs(); val c = loadCalls(); match(c, r)
            runOnUiThread { recs = r; all = c; refresh() }
        }.start()
    }

    private fun loadOwn(): List<Rec> {
        val dir = getExternalFilesDir("rec") ?: return emptyList()
        return (dir.listFiles() ?: emptyArray()).filter { it.isFile }
            .map { Rec(Uri.fromFile(it), it.name, it.lastModified(), it.length()) }
    }

    private fun loadRecs(): List<Rec> = loadExternalRecs() + loadOwn()

    private fun loadExternalRecs(): List<Rec> {
        val tree = getSharedPreferences("p", MODE_PRIVATE).getString("tree", null)
        if (tree != null) {
            val r = loadFromTree(Uri.parse(tree))
            diag = "Tanlangan papka: ${r.size} ta fayl"
            return r
        }
        val list = mutableListOf<Pair<Rec, String>>()
        val paths = HashMap<String, Int>()
        try {
            val p = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DATE_MODIFIED, MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.RELATIVE_PATH)
            contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, p, null, null,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC")?.use {
                while (it.moveToNext()) {
                    val path = it.getString(4) ?: ""
                    paths[path] = (paths[path] ?: 0) + 1
                    list += Rec(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it.getLong(0)),
                        it.getString(1) ?: "", it.getLong(2) * 1000, it.getLong(3)) to path
                }
            }
        } catch (_: Exception) {}
        diag = if (paths.isEmpty()) "Telefonda audio fayl ko'rinmadi (ruxsatni tekshiring)"
               else "Audio papkalar: " + paths.entries.sortedByDescending { it.value }.take(8)
                    .joinToString { "${it.key.ifBlank { "/" }} (${it.value})" }
        val calls = list.filter { it.second.contains("call", true) }
        val chosen = if (calls.isNotEmpty()) calls else list.filter {
            Regex("call|record|запис|звон|rec", RegexOption.IGNORE_CASE).containsMatchIn(it.second + it.first.name) }
        return chosen.map { it.first }
    }

    private fun loadFromTree(tree: Uri, docId: String = DocumentsContract.getTreeDocumentId(tree), depth: Int = 0): List<Rec> {
        val out = mutableListOf<Rec>()
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val p = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_MIME_TYPE)
            contentResolver.query(children, p, null, null, null)?.use {
                while (it.moveToNext()) {
                    val id = it.getString(0); val mime = it.getString(4) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < 2) out += loadFromTree(tree, id, depth + 1)
                    } else if (mime.startsWith("audio") || mime.startsWith("video") ||
                        (it.getString(1) ?: "").lowercase().matches(Regex(".*\\.(m4a|mp3|amr|3gp|aac|wav|ogg|mp4)"))) {
                        out += Rec(DocumentsContract.buildDocumentUriUsingTree(tree, id),
                            it.getString(1) ?: "", it.getLong(2), it.getLong(3))
                    }
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun loadCalls(): List<Call> {
        val out = mutableListOf<Call>()
        try {
            val p = arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE,
                CallLog.Calls.DURATION, CallLog.Calls.TYPE)
            contentResolver.query(CallLog.Calls.CONTENT_URI, p, null, null, "${CallLog.Calls.DATE} DESC")?.use {
                while (it.moveToNext() && out.size < 3000)
                    out += Call(it.getString(0) ?: "", it.getString(1), it.getLong(2), it.getLong(3), it.getInt(4))
            }
        } catch (_: Exception) {}
        return out
    }

    // Fayl nomidagi vaqt (yyMMdd_HHmmss) = yozuv boshlangan vaqt
    private fun startOf(r: Rec): Long {
        val m = Regex("""(\d{2})(\d{2})(\d{2})[_-](\d{2})(\d{2})(\d{2})""").find(r.name) ?: return 0L
        val g = m.groupValues.drop(1).map { it.toInt() }
        return try {
            Calendar.getInstance().apply { clear(); set(2000 + g[0], g[1] - 1, g[2], g[3], g[4], g[5]) }.timeInMillis
        } catch (_: Exception) { 0L }
    }

    // Yozuvni qo'ng'iroqqa vaqt (va fayl nomidagi raqam) bo'yicha bog'laydi
    private fun match(calls: List<Call>, recs: List<Rec>) {
        val used = HashSet<Uri>()
        for (c in calls) {
            if (c.dur <= 0) continue
            val tail = c.number.filter { it.isDigit() }.takeLast(7)
            var best: Rec? = null; var bestDiff = Long.MAX_VALUE
            for (r in recs) {
                if (r.uri in used) continue
                val st = startOf(r)
                val diff: Long
                if (st > 0 && r.name.startsWith("rec_")) {
                    val callEnd = c.date + c.dur * 1000 + 45_000
                    val ov = minOf(r.endMs, callEnd) - maxOf(st, c.date)
                    if (ov < 3_000) continue
                    diff = -ov
                } else if (st > 0) {
                    val d = st - c.date
                    if (d < -15_000 || d > 180_000) continue
                    diff = abs(d - 5_000)
                } else {
                    val d = r.endMs - (c.date + c.dur * 1000)
                    if (d < -30_000 || d > 180_000) continue
                    diff = abs(d)
                }
                val nd = r.name.replace(Regex("""\d{6}[_-]\d{6}"""), "").filter { it.isDigit() }
                if (tail.length == 7 && nd.length >= 7 && !nd.contains(tail)) continue
                if (diff < bestDiff) { bestDiff = diff; best = r }
            }
            if (best != null) { c.rec = best; used += best.uri }
        }
    }

    private fun showAllRecs() {
        if (recs.isEmpty()) { Toast.makeText(this, "Yozuv yo'q", Toast.LENGTH_SHORT).show(); return }
        val sorted = recs.sortedByDescending { it.endMs }
        val labels = sorted.map { "${it.name}\n${fmt.format(Date(it.endMs))} · ${it.size / 1024} KB" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Barcha yozuvlar (${sorted.size})")
            .setItems(labels) { _, i ->
                val r = sorted[i]
                play(Call(r.name, null, r.endMs, 0, 0, r))
            }.setNegativeButton("Yopish", null).show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Kalendar").setIcon(R.drawable.ic_calendar).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        menu.add(0, 2, 1, "Sozlamalar").setIcon(R.drawable.ic_gear).setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        1 -> { pickDate(); true }
        2 -> { showSettings(); true }
        else -> super.onOptionsItemSelected(item)
    }

    private fun refresh() {
        var items = all
        if (prefs.getBoolean("only", false)) items = items.filter { it.rec != null }
        val day = dayFilter
        if (day != null) { val end = day + 24L * 3600 * 1000; items = items.filter { it.date in day until end } }
        adapter.items = items
        adapter.notifyDataSetChanged()
        val tv = findViewById<TextView>(R.id.dateFilter)
        if (day != null) {
            tv.visibility = View.VISIBLE
            tv.text = "Sana: ${dayFmt.format(Date(day))}  (hammasini ko'rsatish uchun bosing)"
        } else tv.visibility = View.GONE
        findViewById<TextView>(R.id.empty).visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        updateRecBtn()
    }

    private fun pickDate() {
        val c = Calendar.getInstance(); dayFilter?.let { c.timeInMillis = it }
        val dp = DatePickerDialog(this, { _, y, m, d ->
            dayFilter = Calendar.getInstance().apply { clear(); set(y, m, d, 0, 0, 0) }.timeInMillis
            refresh()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
        dp.setButton(DialogInterface.BUTTON_NEUTRAL, "Barchasi") { _, _ -> dayFilter = null; refresh() }
        dp.show()
    }

    // Yozishni qo'lda boshlash / to'xtatish (ilova ochiq paytida)
    private fun toggleRecord() {
        val h = Handler(Looper.getMainLooper())
        if (RecService.running) {
            stopService(Intent(this, RecService::class.java))
            h.postDelayed({ load() }, 800)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mikrofon ruxsatini bering", Toast.LENGTH_SHORT).show()
            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)); return
        }
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.READ_PHONE_STATE)); return
        }
        @Suppress("DEPRECATION")
        val inCall = try { getSystemService(TelephonyManager::class.java).callState != TelephonyManager.CALL_STATE_IDLE }
                     catch (e: Exception) { false }
        if (!inCall) {
            Toast.makeText(this, "Hozir qo'ng'iroq yo'q. Yozish faqat qo'ng'iroq paytida ishlaydi", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, RecService::class.java))
        Toast.makeText(this, "Yozish boshlandi (karnayni yoqing)", Toast.LENGTH_SHORT).show()
        h.postDelayed({ updateRecBtn() }, 600)
    }

    private fun updateRecBtn() {
        val b = findViewById<ImageButton>(R.id.recBtn)
        val on = RecService.running
        b.setImageResource(if (on) R.drawable.ic_stop else R.drawable.ic_mic)
        b.setBackgroundResource(if (on) R.drawable.bg_rec_on else R.drawable.bg_rec)
    }

    private fun deleteRecs(list: List<Rec>) {
        val own = list.filter { it.uri.scheme == "file" }
        val ext = list.filter { it.uri.scheme != "file" }
        own.forEach { try { java.io.File(it.uri.path!!).delete() } catch (_: Exception) {} }
        if (ext.isEmpty()) { load(); return }
        if (prefs.getString("tree", null) != null) {
            ext.forEach { try { DocumentsContract.deleteDocument(contentResolver, it.uri) } catch (_: Exception) {} }
            load(); return
        }
        try {
            val sender = MediaStore.createDeleteRequest(contentResolver, ext.map { it.uri }).intentSender
            deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
        } catch (e: Exception) {
            Toast.makeText(this, "O'chirib bo'lmadi", Toast.LENGTH_SHORT).show(); load()
        }
    }

    private fun confirmDelete(c: Call) {
        val r = c.rec ?: return
        AlertDialog.Builder(this)
            .setMessage("Bu yozuv o'chirilsinmi?\n${fmt.format(Date(c.date))} · ${r.size / 1024} KB")
            .setPositiveButton("O'chirish") { _, _ -> deleteRecs(listOf(r)) }
            .setNegativeButton("Yo'q", null).show()
    }

    private fun cleanOld() {
        val limit = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        val old = recs.filter { it.endMs < limit }
        if (old.isEmpty()) { Toast.makeText(this, "30 kundan eski yozuv yo'q", Toast.LENGTH_SHORT).show(); return }
        val mb = old.sumOf { it.size } / 1024.0 / 1024.0
        AlertDialog.Builder(this).setMessage("${old.size} ta yozuv (${"%.1f".format(mb)} MB) o'chirilsinmi?")
            .setPositiveButton("Ha") { _, _ -> deleteRecs(old) }
            .setNegativeButton("Yo'q", null).show()
    }

    private fun showSettings() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null)
        val mb = recs.sumOf { it.size } / 1024.0 / 1024.0
        v.findViewById<TextView>(R.id.summary).text = "Yozuvlar: ${recs.size} ta, ${"%.1f".format(mb)} MB\n$diag"
        val cb = v.findViewById<CheckBox>(R.id.onlyRec)
        cb.isChecked = prefs.getBoolean("only", false)
        cb.setOnCheckedChangeListener { _, ch -> prefs.edit().putBoolean("only", ch).apply(); refresh() }
        val d = AlertDialog.Builder(this).setTitle("Sozlamalar").setView(v).setPositiveButton("Yopish", null).create()
        v.findViewById<Button>(R.id.all).setOnClickListener { d.dismiss(); showAllRecs() }
        v.findViewById<Button>(R.id.pick).setOnClickListener { d.dismiss(); treeLauncher.launch(null) }
        v.findViewById<Button>(R.id.clean).setOnClickListener { d.dismiss(); cleanOld() }
        d.show()
    }

    private fun play(c: Call) {
        val rec = c.rec ?: return
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_player, null)
        val seek = v.findViewById<SeekBar>(R.id.seek)
        val playBtn = v.findViewById<ImageButton>(R.id.play)
        val time = v.findViewById<TextView>(R.id.time)
        val speedBtn = v.findViewById<Button>(R.id.speed)
        v.findViewById<TextView>(R.id.pTitle).text = "${c.name ?: c.number}\n${fmt.format(Date(c.date))}"
        val mp = MediaPlayer()
        val h = Handler(Looper.getMainLooper())
        try { mp.setDataSource(this, rec.uri); mp.prepare() }
        catch (e: Exception) { Toast.makeText(this, "Ochib bo'lmadi", Toast.LENGTH_SHORT).show(); mp.release(); return }
        seek.max = mp.duration
        val tick = object : Runnable { override fun run() {
            seek.progress = mp.currentPosition
            time.text = "${dur(mp.currentPosition / 1000L)} / ${dur(mp.duration / 1000L)}"
            if (mp.isPlaying) h.postDelayed(this, 500)
        } }
        fun start() { mp.start(); playBtn.setImageResource(android.R.drawable.ic_media_pause); h.post(tick) }
        playBtn.setOnClickListener {
            if (mp.isPlaying) { mp.pause(); playBtn.setImageResource(android.R.drawable.ic_media_play) } else start()
        }
        mp.setOnCompletionListener { playBtn.setImageResource(android.R.drawable.ic_media_play); tick.run() }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { mp.seekTo(p); time.text = "${dur(p / 1000L)} / ${dur(mp.duration / 1000L)}" } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val speeds = floatArrayOf(1f, 1.5f, 2f, 0.75f); var si = 0
        speedBtn.setOnClickListener {
            si = (si + 1) % speeds.size
            try { mp.playbackParams = mp.playbackParams.setSpeed(speeds[si]); if (!mp.isPlaying) mp.pause() } catch (_: Exception) {}
            speedBtn.text = "${speeds[si]}x"
        }
        val d = AlertDialog.Builder(this).setView(v).setOnDismissListener { h.removeCallbacksAndMessages(null); mp.release() }.create()
        d.show(); start()
    }

    private fun dur(s: Long) = "%d:%02d".format(s / 60, s % 60)

    inner class CallAdapter : RecyclerView.Adapter<CallAdapter.VH>() {
        var items = listOf<Call>()
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val type: TextView = v.findViewById(R.id.type); val title: TextView = v.findViewById(R.id.title)
            val sub: TextView = v.findViewById(R.id.sub); val mic: ImageButton = v.findViewById(R.id.mic)
            val del: ImageButton = v.findViewById(R.id.del)
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_call, p, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(h: VH, i: Int) {
            val c = items[i]
            h.type.text = when (c.type) {
                CallLog.Calls.OUTGOING_TYPE -> "↗"; CallLog.Calls.INCOMING_TYPE -> "↙"; else -> "✕" }
            h.type.setTextColor(when (c.type) {
                CallLog.Calls.OUTGOING_TYPE -> 0xFF1B7F3B.toInt()
                CallLog.Calls.INCOMING_TYPE -> 0xFF1A56C4.toInt()
                else -> 0xFFC62828.toInt() })
            h.title.text = if (c.name.isNullOrBlank()) c.number.ifBlank { "Noma'lum" } else c.name
            h.sub.text = (if (c.name.isNullOrBlank()) "" else c.number + " · ") +
                "${fmt.format(Date(c.date))} · ${dur(c.dur)}"
            val has = if (c.rec != null) View.VISIBLE else View.INVISIBLE
            h.mic.visibility = has; h.del.visibility = has
            h.mic.setOnClickListener { play(c) }
            h.del.setOnClickListener { confirmDelete(c) }
        }
    }
}
