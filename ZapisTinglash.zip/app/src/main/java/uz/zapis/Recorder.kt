package uz.zapis

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.SystemClock
import java.io.File
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.sqrt

// Yozuvchi (API o'zgarmagan: start / stop / running).
// Manbalar tartibi: VOICE_CALL (ishlasa — ikkala tomon karnaysiz) -> VOICE_RECOGNITION (Android 10+ da qo'ng'iroq
// paytida mikrofon aynan shu manbada jim bo'lmaydi) -> UNPROCESSED -> MIC.
// Agar tanlangan manba 3 soniya davomida mutlaqo jim (nol) bo'lsa, avtomatik keyingisiga o'tadi.
// Shovqin bosish / AGC / exo-bekor qilish effektlari o'chiriladi, o'rniga dasturiy AGC (past ovozni kuchaytiradi).
object Recorder {
    @Volatile var running = false

    private const val RATE = 16000
    private const val CHUNK = 1600            // 100 ms
    private const val MAX_MS = 3L * 3600 * 1000
    private const val TARGET_RMS = 3500f
    private const val MAX_GAIN = 40f
    private const val NOISE_FLOOR = 10f
    private const val SILENT_SWITCH_SAMPLES = 3 * RATE

    private val SOURCES = intArrayOf(
        MediaRecorder.AudioSource.VOICE_RECOGNITION,
        MediaRecorder.AudioSource.UNPROCESSED,
        MediaRecorder.AudioSource.MIC
    )

    private var worker: Thread? = null
    @Volatile private var stopFlag = false
    private val fx = mutableListOf<AudioEffect>()

    private fun bufBytes(): Int {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return if (min <= 0) 0 else maxOf(min * 4, RATE * 2)
    }

    @SuppressLint("MissingPermission")
    private fun tryOpen(src: Int, bytes: Int): AudioRecord? {
        return try {
            val r = AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bytes)
            if (r.state == AudioRecord.STATE_INITIALIZED) r else { r.release(); null }
        } catch (_: Throwable) { null }
    }

    private fun disableEffects(r: AudioRecord) {
        val id = r.audioSessionId
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(id)?.let { it.enabled = false; fx.add(it) } } catch (_: Throwable) {}
        try { if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(id)?.let { it.enabled = false; fx.add(it) } } catch (_: Throwable) {}
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(id)?.let { it.enabled = false; fx.add(it) } } catch (_: Throwable) {}
    }

    private fun releaseEffects() {
        for (e in fx) { try { e.release() } catch (_: Throwable) {} }
        fx.clear()
    }

    // VOICE_CALL: qo'ng'iroqning ikkala tomoni. Ko'p telefonlarda yopiq; ~0.6 s sinab, jim bo'lsa rad etamiz.
    private fun tryVoiceCall(bytes: Int): AudioRecord? {
        val r = tryOpen(MediaRecorder.AudioSource.VOICE_CALL, bytes) ?: return null
        return try {
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) { r.release(); return null }
            val tmp = ShortArray(CHUNK)
            var peak = 0
            repeat(6) {
                val n = r.read(tmp, 0, tmp.size)
                for (i in 0 until maxOf(n, 0)) { val a = abs(tmp[i].toInt()); if (a > peak) peak = a }
            }
            if (peak > 0) r else { try { r.stop() } catch (_: Throwable) {}; r.release(); null }
        } catch (_: Throwable) { try { r.release() } catch (_: Throwable) {}; null }
    }

    // SOURCES[from..] dan birinchi ochilganini qaytaradi (AudioRecord, indeks) va yozishni boshlaydi
    private fun openFrom(from: Int, bytes: Int): Pair<AudioRecord, Int>? {
        for (i in from until SOURCES.size) {
            val r = tryOpen(SOURCES[i], bytes) ?: continue
            disableEffects(r)
            try {
                r.startRecording()
                if (r.recordingState == AudioRecord.RECORDSTATE_RECORDING) return Pair(r, i)
            } catch (_: Throwable) {}
            try { r.release() } catch (_: Throwable) {}
        }
        return null
    }

    @Synchronized fun start(ctx: Context): Boolean {
        if (worker != null) return true
        val dir = ctx.getExternalFilesDir("rec") ?: ctx.filesDir
        dir.mkdirs()
        val f = File(dir, "rec_" + SimpleDateFormat("yyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a")
        val bytes = bufBytes()
        if (bytes == 0) return false

        var ar: AudioRecord? = null
        var idx = SOURCES.size              // VOICE_CALL ishlasa, zaxira manbaga o'tmaymiz
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        try {
            ar = tryVoiceCall(bytes)
            if (ar == null) {
                val p = openFrom(0, bytes) ?: return false
                ar = p.first; idx = p.second
            }
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1)
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 32000)
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        } catch (e: Throwable) {
            try { ar?.release() } catch (_: Throwable) {}
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { muxer?.release() } catch (_: Throwable) {}
            releaseEffects()
            f.delete()
            return false
        }

        stopFlag = false
        running = true
        val a = ar!!; val c = codec!!; val m = muxer!!; val i0 = idx
        val t = Thread { loop(a, i0, bytes, c, m, f) }
        t.name = "rec-loop"
        worker = t
        t.start()
        return true
    }

    @Synchronized fun stop() {
        val t = worker ?: return
        stopFlag = true
        try { t.join(3000) } catch (_: InterruptedException) {}
        worker = null
        running = false
    }

    private fun loop(ar0: AudioRecord, idx0: Int, bytes: Int, codec: MediaCodec, muxer: MediaMuxer, f: File) {
        var ar = ar0
        var idx = idx0
        val info = MediaCodec.BufferInfo()
        val pcm = ShortArray(CHUNK)
        var track = -1
        var muxStarted = false
        var totalSamples = 0L
        var gain = 6f
        var zeroRun = 0
        var heardSound = false
        val t0 = SystemClock.elapsedRealtime()

        fun drain(eos: Boolean) {
            val deadline = SystemClock.elapsedRealtime() + 2000
            while (true) {
                val o = codec.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos || SystemClock.elapsedRealtime() > deadline) return
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxStarted) { track = muxer.addTrack(codec.outputFormat); muxer.start(); muxStarted = true }
                } else if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (ob != null && info.size > 0 && muxStarted) {
                        ob.position(info.offset); ob.limit(info.offset + info.size)
                        muxer.writeSampleData(track, ob, info)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }

        try {
            while (!stopFlag && SystemClock.elapsedRealtime() - t0 < MAX_MS) {
                val n = ar.read(pcm, 0, pcm.size)
                if (n < 0) break
                if (n == 0) continue

                // jim (nol) manbani aniqlash -> keyingi manbaga o'tish
                var peak = 0
                for (i in 0 until n) { val a = abs(pcm[i].toInt()); if (a > peak) peak = a }
                if (peak > 0) { heardSound = true; zeroRun = 0 } else zeroRun += n
                if (!heardSound && zeroRun >= SILENT_SWITCH_SAMPLES && idx + 1 < SOURCES.size) {
                    try { ar.stop() } catch (_: Throwable) {}
                    try { ar.release() } catch (_: Throwable) {}
                    releaseEffects()
                    val p = openFrom(idx + 1, bytes) ?: break
                    ar = p.first; idx = p.second; zeroRun = 0
                    continue
                }

                gain = applyGain(pcm, n, gain)

                var inIdx = codec.dequeueInputBuffer(10_000L)
                var tries = 0
                while (inIdx < 0 && tries++ < 50) { drain(false); inIdx = codec.dequeueInputBuffer(10_000L) }
                if (inIdx < 0) continue
                val ib = codec.getInputBuffer(inIdx) ?: continue
                ib.clear(); ib.order(ByteOrder.LITTLE_ENDIAN)
                ib.asShortBuffer().put(pcm, 0, n)
                codec.queueInputBuffer(inIdx, 0, n * 2, totalSamples * 1_000_000L / RATE, 0)
                totalSamples += n
                drain(false)
            }
            val e = codec.dequeueInputBuffer(100_000L)
            if (e >= 0) {
                codec.queueInputBuffer(e, 0, 0, totalSamples * 1_000_000L / RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                drain(true)
            }
        } catch (_: Throwable) {
        } finally {
            try { ar.stop() } catch (_: Throwable) {}
            try { ar.release() } catch (_: Throwable) {}
            releaseEffects()
            try { codec.stop() } catch (_: Throwable) {}
            try { codec.release() } catch (_: Throwable) {}
            try { if (muxStarted) muxer.stop() } catch (_: Throwable) {}
            try { muxer.release() } catch (_: Throwable) {}
            if (!muxStarted || SystemClock.elapsedRealtime() - t0 < 2000) f.delete()
            running = false
        }
    }

    private fun applyGain(p: ShortArray, n: Int, g0: Float): Float {
        var sum = 0.0
        for (i in 0 until n) { val v = p[i].toDouble(); sum += v * v }
        val rms = sqrt(sum / n).toFloat()
        var g = g0
        if (rms > NOISE_FLOOR) {
            val want = (TARGET_RMS / rms).coerceIn(1f, MAX_GAIN)
            g += (want - g) * (if (want < g) 0.6f else 0.15f)
        }
        val step = (g - g0) / n
        var cur = g0
        for (i in 0 until n) {
            cur += step
            p[i] = (p[i] * cur).toInt().coerceIn(-32768, 32767).toShort()
        }
        return g
    }
}
