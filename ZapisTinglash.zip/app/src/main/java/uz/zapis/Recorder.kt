package uz.zapis

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.os.SystemClock
import java.io.File
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sqrt

// Yagona yozuvchi (API o'zgarmagan: start / stop / running).
//
// MUHIM O'ZGARISH: avval MediaRecorder + VOICE_RECOGNITION ishlatilgan edi. Bu manba shovqin bosish (NS)
// va avto-kuchaytirish qiladi, shuning uchun quloq karnayidan (earpiece) mikrofonga zo'rg'a yetib kelgan
// past ovoz "shovqin" deb kesib tashlanardi. Endi:
//  1) AudioRecord + UNPROCESSED (yo'q bo'lsa MIC) — hech qanday shovqin bosish yo'q;
//  2) dasturiy AGC — past ovoz (suhbatdoshniki) 40 martagacha kuchaytiriladi, o'zingizniki baland bo'lsa
//     kuchaytirish tez pasayadi (clipping bo'lmaydi);
//  3) MediaCodec AAC (16 kHz, mono, 32 kbit/s) -> .m4a (MainActivity pleyeri o'zgarishsiz ishlaydi).
object Recorder {
    @Volatile var running = false

    private const val RATE = 16000
    private const val CHUNK = 1600            // 100 ms
    private const val MAX_MS = 3L * 3600 * 1000
    private const val TARGET_RMS = 3500f      // maqsadli ovoz darajasi
    private const val MAX_GAIN = 40f          // ~32 dB
    private const val NOISE_FLOOR = 10f       // shundan pastini kuchaytirmaymiz (sukunat)

    private var worker: Thread? = null
    private var file: File? = null
    @Volatile private var stopFlag = false

    @SuppressLint("MissingPermission")
    private fun tryOpen(src: Int, bytes: Int): AudioRecord? {
        return try {
            val r = AudioRecord(src, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bytes)
            if (r.state == AudioRecord.STATE_INITIALIZED) r else { r.release(); null }
        } catch (_: Throwable) { null }
    }

    // VOICE_CALL = qo'ng'iroqning ikkala tomoni (suhbatdosh ham) to'g'ridan-to'g'ri, karnaysiz.
    // Android 10+ da odatda faqat tizim ilovalariga ruxsat, ammo ayrim telefonlarda/ROM'larda ishlaydi.
    // Ishlasa-ishlamasligini ~0.6 s sinab ko'ramiz: jim (nol) chiqsa, oddiy mikrofonga o'tamiz.
    private fun tryVoiceCall(bytes: Int): AudioRecord? {
        val r = tryOpen(MediaRecorder.AudioSource.VOICE_CALL, bytes) ?: return null
        return try {
            r.startRecording()
            if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) { r.release(); return null }
            val tmp = ShortArray(CHUNK)
            var peak = 0
            repeat(6) {
                val n = r.read(tmp, 0, tmp.size)
                for (i in 0 until maxOf(n, 0)) { val a = kotlin.math.abs(tmp[i].toInt()); if (a > peak) peak = a }
            }
            if (peak > 0) r else { try { r.stop() } catch (_: Throwable) {}; r.release(); null }
        } catch (_: Throwable) { try { r.release() } catch (_: Throwable) {}; null }
    }

    private fun openAudioRecord(): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        val bytes = maxOf(min * 4, RATE * 2)
        tryVoiceCall(bytes)?.let { return it }
        val sources = intArrayOf(
            MediaRecorder.AudioSource.UNPROCESSED,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.VOICE_RECOGNITION
        )
        for (s in sources) tryOpen(s, bytes)?.let { return it }
        return null
    }

    @Synchronized fun start(ctx: Context): Boolean {
        if (worker != null) return true
        val dir = ctx.getExternalFilesDir("rec") ?: ctx.filesDir
        dir.mkdirs()
        val f = File(dir, "rec_" + SimpleDateFormat("yyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a")

        var ar: AudioRecord? = null
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        try {
            ar = openAudioRecord() ?: return false
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 1)
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 32000)
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            muxer = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            ar.startRecording()
            if (ar.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("mic busy")
        } catch (e: Throwable) {
            try { ar?.release() } catch (_: Throwable) {}
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { muxer?.release() } catch (_: Throwable) {}
            f.delete()
            return false
        }

        stopFlag = false
        file = f
        running = true
        val a = ar!!; val c = codec!!; val m = muxer!!
        val t = Thread { loop(a, c, m, f) }
        t.name = "rec-loop"
        worker = t
        t.start()
        return true
    }

    @Synchronized fun stop() {
        val t = worker ?: return
        stopFlag = true
        try { t.join(3000) } catch (_: InterruptedException) {}
        worker = null
        running = false
    }

    // ---- yozish sikli (alohida oqimda) ----
    private fun loop(ar: AudioRecord, codec: MediaCodec, muxer: MediaMuxer, f: File) {
        val info = MediaCodec.BufferInfo()
        val pcm = ShortArray(CHUNK)
        var track = -1
        var muxStarted = false
        var totalSamples = 0L
        var gain = 6f
        val t0 = SystemClock.elapsedRealtime()

        // kodek chiqishini muxer'ga yozadi; eos=true bo'lsa oqim tugaguncha kutadi
        fun drain(eos: Boolean) {
            val deadline = SystemClock.elapsedRealtime() + 2000
            while (true) {
                val o = codec.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
                if (o == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos || SystemClock.elapsedRealtime() > deadline) return
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxStarted) { track = muxer.addTrack(codec.outputFormat); muxer.start(); muxStarted = true }
                } else if (o >= 0) {
                    val ob = codec.getOutputBuffer(o)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (ob != null && info.size > 0 && muxStarted) {
                        ob.position(info.offset); ob.limit(info.offset + info.size)
                        muxer.writeSampleData(track, ob, info)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }

        try {
            while (!stopFlag && SystemClock.elapsedRealtime() - t0 < MAX_MS) {
                val n = ar.read(pcm, 0, pcm.size)
                if (n < 0) break
                if (n == 0) continue
                gain = applyGain(pcm, n, gain)

                var idx = codec.dequeueInputBuffer(10_000L)
                var tries = 0
                while (idx < 0 && tries++ < 50) { drain(false); idx = codec.dequeueInputBuffer(10_000L) }
                if (idx < 0) continue
                val ib = codec.getInputBuffer(idx) ?: continue
                ib.clear(); ib.order(ByteOrder.LITTLE_ENDIAN)
                ib.asShortBuffer().put(pcm, 0, n)
                codec.queueInputBuffer(idx, 0, n * 2, totalSamples * 1_000_000L / RATE, 0)
                totalSamples += n
                drain(false)
            }
            // oqimni yopish
            var idx = codec.dequeueInputBuffer(100_000L)
            if (idx >= 0) {
                codec.queueInputBuffer(idx, 0, 0, totalSamples * 1_000_000L / RATE, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                drain(true)
            }
        } catch (_: Throwable) {
        } finally {
            try { ar.stop() } catch (_: Throwable) {}
            try { ar.release() } catch (_: Throwable) {}
            try { codec.stop() } catch (_: Throwable) {}
            try { codec.release() } catch (_: Throwable) {}
            try { if (muxStarted) muxer.stop() } catch (_: Throwable) {}
            try { muxer.release() } catch (_: Throwable) {}
            if (!muxStarted || SystemClock.elapsedRealtime() - t0 < 2000) f.delete()
            running = false
        }
    }

    // Dasturiy AGC: past ovozni ko'taradi, baland ovozda tez pasaytiradi. Blok ichida gain silliq o'zgaradi.
    private fun applyGain(p: ShortArray, n: Int, g0: Float): Float {
        var sum = 0.0
        for (i in 0 until n) { val v = p[i].toDouble(); sum += v * v }
        val rms = sqrt(sum / n).toFloat()
        var g = g0
        if (rms > NOISE_FLOOR) {
            val want = (TARGET_RMS / rms).coerceIn(1f, MAX_GAIN)
            g += (want - g) * (if (want < g) 0.6f else 0.15f)   // pasayish tez, ko'tarilish sekinroq
        }
        val step = (g - g0) / n
        var cur = g0
        for (i in 0 until n) {
            cur += step
            p[i] = (p[i] * cur).toInt().coerceIn(-32768, 32767).toShort()
        }
        return g
    }
}
