package uz.zapis

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// Yagona yozuvchi. Kichik hajm: 16 kHz, mono, 24 kbit/s AAC (~11 MB/soat).
object Recorder {
    @Volatile var running = false
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    @Synchronized fun start(ctx: Context): Boolean {
        if (rec != null) return true
        val dir = ctx.getExternalFilesDir("rec") ?: ctx.filesDir
        dir.mkdirs()
        val f = File(dir, "rec_" + SimpleDateFormat("yyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a")
        return try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(16000)
            r.setAudioChannels(1)
            r.setAudioEncodingBitRate(24000)
            r.setMaxDuration(3 * 3600 * 1000) // xavfsizlik: 3 soatdan oshmaydi
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) stop()
            }
            r.setOutputFile(f.absolutePath)
            r.prepare(); r.start()
            rec = r; file = f; startedAt = System.currentTimeMillis(); running = true
            true
        } catch (e: Exception) { f.delete(); false }
    }

    @Synchronized fun stop() {
        val r = rec ?: return
        try { r.stop() } catch (_: Exception) {
            if (System.currentTimeMillis() - startedAt < 2000) file?.delete()
        }
        try { r.release() } catch (_: Exception) {}
        rec = null; running = false
    }
}
