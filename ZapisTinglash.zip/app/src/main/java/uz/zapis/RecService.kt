package uz.zapis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// Faqat qo'ng'iroq davomida, foydalanuvchi tugmani bosgandan keyin ishlaydi.
// Kichik hajm: 16 kHz, mono, 24 kbit/s AAC (~11 MB/soat).
class RecService : Service() {
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L

    companion object { @Volatile var running = false }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (rec != null) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Yozish", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, RecService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Qo'ng'iroq yozilmoqda")
            .addAction(Notification.Action.Builder(0, "To'xtatish", stop).build())
            .setOngoing(true).build()
        try {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        nm.cancel(1)
        val dir = getExternalFilesDir("rec") ?: filesDir
        dir.mkdirs()
        val name = "rec_" + SimpleDateFormat("yyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a"
        file = File(dir, name)
        try {
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(16000)
            r.setAudioChannels(1)
            r.setAudioEncodingBitRate(24000)
            r.setOutputFile(file!!.absolutePath)
            r.prepare(); r.start()
            rec = r; startedAt = System.currentTimeMillis(); running = true
        } catch (e: Exception) { file?.delete(); stopSelf() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { rec?.stop() } catch (_: Exception) {
            if (System.currentTimeMillis() - startedAt < 2000) file?.delete()
        }
        try { rec?.release() } catch (_: Exception) {}
        rec = null
        running = false
        super.onDestroy()
    }
}
