package uz.zapis

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.widget.Toast

// Qo'lda boshlash / bildirishnoma tugmasi uchun. Faqat qo'ng'iroq davomida yozadi.
class RecService : Service() {
    private var tm: TelephonyManager? = null
    private var watcher: Any? = null
    private var owns = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Yozish", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, RecService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Qo'ng'iroq yozilmoqda")
            .addAction(Notification.Action.Builder(0, "To'xtatish", stop).build())
            .setOngoing(true).build()
        try {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        @Suppress("DEPRECATION")
        val inCall = try {
            getSystemService(TelephonyManager::class.java).callState != TelephonyManager.CALL_STATE_IDLE
        } catch (e: Exception) { false }
        if (!inCall) {
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(applicationContext, "Yozish faqat qo'ng'iroq paytida ishlaydi", Toast.LENGTH_LONG).show()
            }
            stopSelf(); return START_NOT_STICKY
        }
        if (Recorder.running) { stopSelf(); return START_NOT_STICKY }
        watchCall()
        nm.cancel(1)
        owns = Recorder.start(applicationContext)
        if (!owns) stopSelf()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun watchCall() {
        val t = getSystemService(TelephonyManager::class.java); tm = t
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val c = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) {
                        if (state == TelephonyManager.CALL_STATE_IDLE) stopSelf()
                    }
                }
                t.registerTelephonyCallback(mainExecutor, c); watcher = c
            } else {
                val l = object : PhoneStateListener() {
                    override fun onCallStateChanged(state: Int, number: String?) {
                        if (state == TelephonyManager.CALL_STATE_IDLE) stopSelf()
                    }
                }
                t.listen(l, PhoneStateListener.LISTEN_CALL_STATE); watcher = l
            }
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun unwatchCall() {
        try {
            if (Build.VERSION.SDK_INT >= 31) (watcher as? TelephonyCallback)?.let { tm?.unregisterTelephonyCallback(it) }
            else (watcher as? PhoneStateListener)?.let { tm?.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (_: Exception) {}
        watcher = null
    }

    override fun onDestroy() {
        unwatchCall()
        if (owns) Recorder.stop()
        super.onDestroy()
    }
}
