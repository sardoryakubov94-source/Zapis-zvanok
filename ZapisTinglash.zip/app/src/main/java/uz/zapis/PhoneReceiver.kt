package uz.zapis

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

// Faqat qo'ng'iroq boshlanganda/tugaganda bir lahzaga ishga tushadi, boshqa vaqtda batareya sarflamaydi.
class PhoneReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val nm = c.getSystemService(NotificationManager::class.java)
        when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                // Avto-yozish yoqilgan bo'lsa (Maxsus imkoniyatlar), o'zi boshlaydi
                if (CallAccessibility.instance != null) {
                    Recorder.start(c.applicationContext)
                    return
                }
                // Aks holda: bildirishnomadagi tugma
                nm.createNotificationChannel(NotificationChannel("call", "Qo'ng'iroq", NotificationManager.IMPORTANCE_HIGH))
                val pi = PendingIntent.getForegroundService(c, 1, Intent(c, RecService::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val n = Notification.Builder(c, "call")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Qo'ng'iroq davom etmoqda")
                    .setContentText("Yozish uchun tugmani bosing (karnayni yoqing)")
                    .addAction(Notification.Action.Builder(0, "Yozishni boshlash", pi).build())
                    .setAutoCancel(true).build()
                nm.notify(1, n)
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                Recorder.stop()
                c.stopService(Intent(c, RecService::class.java))
                nm.cancel(1)
            }
        }
    }
}
